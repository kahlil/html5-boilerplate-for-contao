/* Author: 

*/

/* Use this syntax for your jQuery code if you use two js libs using the $ placeholder
$.noConflict();
jQuery(document).ready(function($) {
  // Code that uses jQuery's $ can follow here.
	$(function(){
		
	});
}); */






















